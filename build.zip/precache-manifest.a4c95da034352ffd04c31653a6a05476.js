self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "80b438b1acedc42d1a58cb7c4bdd74e6",
    "url": "/index.html"
  },
  {
    "revision": "965adff6158e68f3118c",
    "url": "/static/css/main.b8e88177.chunk.css"
  },
  {
    "revision": "705431e030763ee21d26",
    "url": "/static/js/2.faf23ebb.chunk.js"
  },
  {
    "revision": "46f91ec18259a53c6f750cd89192fcc8",
    "url": "/static/js/2.faf23ebb.chunk.js.LICENSE.txt"
  },
  {
    "revision": "965adff6158e68f3118c",
    "url": "/static/js/main.078c71d8.chunk.js"
  },
  {
    "revision": "f64bbedbc980241ccee0",
    "url": "/static/js/runtime-main.18399cad.js"
  },
  {
    "revision": "5d5d9eefa31e5e13a6610d9fa7a283bb",
    "url": "/static/media/logo.5d5d9eef.svg"
  }
]);